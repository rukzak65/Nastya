"""Build the Ice Baby record in Blender 4.3+.

Run from a folder with the supplied fonts directory:
  blender -b --factory-startup -P ice_baby.py -- --output ice-baby.blend
To include the record on the walnut turntable, open its blend as the input:
  blender -b turntable.blend -P ice_baby.py -- --output ice-baby.blend

All construction coordinates below are in millimetres.
"""
import argparse
import math
import random
import sys
from pathlib import Path

import _cycles
import bpy
from mathutils import Vector

MM = 0.001
TAU = math.tau
RECORD_R = 152.4
HOLE_R = 3.78
LABEL_R = 65.3
LABEL_FACE = 6.49
TEXT_Z = LABEL_FACE + 0.035
CREDIT = "PRODUCED BY ANACTASIA PONITKOVA"


def metres(point):
    return tuple(v * MM for v in point)


def linear(color):
    parts = [int(color[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    return (*[v / 12.92 if v < 0.04045 else ((v + 0.055) / 1.055) ** 2.4 for v in parts], 1)


def group(name, parent=None):
    collection = bpy.data.collections.new(name)
    if parent:
        parent.children.link(collection)
    return collection


def mesh(name, vertices, faces, collection, material, smooth=True):
    data = bpy.data.meshes.new(name)
    data.from_pydata([metres(v) for v in vertices], [], faces)
    data.update()
    obj = bpy.data.objects.new(name, data)
    collection.objects.link(obj)
    data.materials.append(material)
    if smooth:
        for face in data.polygons:
            face.use_smooth = True
    return obj


def material(name, hex_color, roughness):
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = linear(hex_color)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = mat.diffuse_color
    bsdf.inputs["Roughness"].default_value = roughness
    return mat, bsdf


def node(mat, kind, label, position):
    n = mat.node_tree.nodes.new(kind)
    n.label = label
    n.location = position
    return n


def plug(mat, value, input_socket):
    if isinstance(value, bpy.types.NodeSocket):
        mat.node_tree.links.new(value, input_socket)
    else:
        input_socket.default_value = value


def noise(mat, vec, scale, detail, xy, label):
    n = node(mat, "ShaderNodeTexNoise", label, xy)
    plug(mat, vec, n.inputs["Vector"])
    n.inputs["Scale"].default_value = scale
    n.inputs["Detail"].default_value = detail
    return n.outputs["Fac"]


def vec_math(mat, op, a, b, xy, label):
    n = node(mat, "ShaderNodeVectorMath", label, xy)
    n.operation = op
    plug(mat, a, n.inputs[0])
    if b is not None:
        plug(mat, b, n.inputs[1])
    return n.outputs["Value" if op == 'LENGTH' else "Vector"]


def scalar(mat, op, a, b, xy, label):
    n = node(mat, "ShaderNodeMath", label, xy)
    n.operation = op
    plug(mat, a, n.inputs[0])
    if b is not None:
        plug(mat, b, n.inputs[1])
    return n.outputs[0]


def remap(mat, signal, from_min, from_max, to_min, to_max, xy, label):
    n = node(mat, "ShaderNodeMapRange", label, xy)
    n.interpolation_type = 'SMOOTHSTEP'
    plug(mat, signal, n.inputs["Value"])
    for key, val in (("From Min", from_min), ("From Max", from_max),
                     ("To Min", to_min), ("To Max", to_max)):
        n.inputs[key].default_value = val
    return n.outputs["Result"]


def bump(mat, signal, depth, strength, xy, label):
    n = node(mat, "ShaderNodeBump", label, xy)
    n.inputs["Distance"].default_value = depth * MM
    n.inputs["Strength"].default_value = strength
    plug(mat, signal, n.inputs["Height"])
    return n.outputs["Normal"]


def ice_material():
    m, surface = material("ICE | refractive shell and trapped frost", "D4E4F7", 0.09)
    surface.inputs["IOR"].default_value = 1.31
    surface.inputs["Base Color"].default_value = (0.79, 0.89, 0.99, 1)
    surface.location = (670, 250)
    output = m.node_tree.nodes.get("Material Output")
    output.location = (1020, 270)
    p = node(m, "ShaderNodeTexCoord", "Local metres from spindle", (-1600, 150)).outputs["Object"]
    flat = vec_math(m, 'MULTIPLY', p, (1, 1, 0), (-1390, 440), "Spindle plane")
    r = vec_math(m, 'LENGTH', flat, None, (-1180, 440), "Radius in the disc")
    band = noise(m, r, 178, 3.2, (-960, 475), "Layered freezing fronts")
    clouds = noise(m, p, 124, 3, (-960, 195), "Patchy frost")
    mix = node(m, "ShaderNodeMixRGB", "Broken concentric frost", (-690, 390))
    mix.inputs[0].default_value = 0.45
    plug(m, band, mix.inputs[1])
    plug(m, clouds, mix.inputs[2])
    field = mix.outputs["Color"]
    rim = remap(m, r, 0.143, 0.1495, 1, 0.18, (-480, 670), "Clear ice near the rolled rim")
    field = scalar(m, 'MULTIPLY', field, rim, (-260, 415), "Frost clears toward the edge")
    rough = remap(m, field, 0.21, 0.73, 0.016, 0.16, (10, 590), "Wet and etched patches")
    transmit = remap(m, field, 0.30, 0.76, 0.999, 0.90, (10, 305), "Mixed clear and frosted surface")
    plug(m, rough, surface.inputs["Roughness"])
    plug(m, transmit, surface.inputs["Transmission Weight"])
    pores = noise(m, p, 2690, 2.0, (-915, -205), "Frozen pitting")
    plug(m, bump(m, pores, 0.026, 0.18, (320, 65), "Micro-relief"), surface.inputs["Normal"])

    # A metre-scale scattering distance of a few millimetres is visible across this slab.
    density = remap(m, field, 0.38, 0.72, 0.8, 285, (0, -275), "Air-rich freezing fronts")
    volume = node(m, "ShaderNodeVolumeScatter", "Blue-white volume scattering", (370, -240))
    volume.inputs["Color"].default_value = (0.63, 0.80, 0.98, 1)
    volume.inputs["Anisotropy"].default_value = 0.08
    plug(m, density, volume.inputs["Density"])
    absorption = node(m, "ShaderNodeVolumeAbsorption", "Faint cool absorption", (370, -450))
    absorption.inputs["Color"].default_value = (0.62, 0.82, 0.99, 1)
    absorption.inputs["Density"].default_value = 11.0
    add = node(m, "ShaderNodeAddShader", "Ice interior", (685, -230))
    plug(m, volume.outputs[0], add.inputs[0])
    plug(m, absorption.outputs[0], add.inputs[1])
    plug(m, add.outputs[0], output.inputs["Volume"])
    return m


def inclusion_material(name, tint, transparency, roughness, ior=1.11):
    m, surface = material(name, tint, roughness)
    surface.inputs["IOR"].default_value = ior
    surface.inputs["Metallic"].default_value = 0.02
    surface.inputs["Transmission Weight"].default_value = 0.33
    clear = node(m, "ShaderNodeBsdfTransparent", "Transparent boundaries", (0, -200))
    combine = node(m, "ShaderNodeMixShader", "Discontinuous air–ice interface", (340, 50))
    combine.inputs[0].default_value = transparency
    plug(m, surface.outputs[0], combine.inputs[1])
    plug(m, clear.outputs[0], combine.inputs[2])
    output = m.node_tree.nodes.get("Material Output")
    output.location = (580, 50)
    plug(m, combine.outputs[0], output.inputs["Surface"])
    return m


def label_material():
    m, surface = material("LABEL | carbon ink and fine frost dots", "131318", 0.83)
    surface.inputs["Specular IOR Level"].default_value = 0.22
    p = node(m, "ShaderNodeTexCoord", "Label coordinates", (-800, 150)).outputs["Object"]
    dust = noise(m, p, 1780, 2, (-575, 130), "Fine granulation")
    n = node(m, "ShaderNodeValToRGB", "Charcoal and scattered white flecks", (-300, 230))
    n.color_ramp.elements[0].position = 0.41
    n.color_ramp.elements[0].color = linear("0C0D11")
    n.color_ramp.elements[1].position = 0.87
    n.color_ramp.elements[1].color = linear("8A8B8E")
    for pos, color in ((0.62, "17171B"), (0.74, "37383D")):
        n.color_ramp.elements.new(pos).color = linear(color)
    plug(m, dust, n.inputs["Fac"])
    plug(m, n.outputs["Color"], surface.inputs["Base Color"])
    plug(m, bump(m, dust, 0.008, 0.23, (-240, -80), "Paper relief"), surface.inputs["Normal"])
    return m


def edge_variation(a):
    return (0.68 * math.sin(3 * a + 0.5) + 0.43 * math.sin(6 * a - 0.65)
            + 0.27 * math.sin(10 * a + 1.85) + 0.14 * math.sin(23 * a)
            + 0.078 * math.sin(53 * a + 0.8))


def rim_height(a):
    return 0.24 * math.sin(5 * a + 1.3) + 0.12 * math.sin(13 * a - 0.8)


def top_surface(r, a):
    wear = max(0, min(1, (r - LABEL_R) / 12))
    grooves = (
        0.085 * math.sin(TAU * (r - 67.0) / 0.66 + 0.32 * math.sin(5 * a + r * 0.12))
        + 0.048 * math.sin(TAU * (r - 66.3) / 1.39 + 0.52 * math.sin(3 * a - r * 0.07))
        - sum(0.21 * math.exp(-((r - gap) / 0.42) ** 2) for gap in (77.8, 93.3, 112.2, 131.0, 142.8))
    )
    wave = 0.17 * math.sin(8 * a + r * 0.106) + 0.085 * math.sin(17 * a - r * 0.201)
    frost_lens = 0.13 * math.sin(r * 0.117 + 2.2 * math.sin(3 * a + 0.9))
    return 6.26 + wear * (grooves + wave + frost_lens) + (r / RECORD_R) ** 9 * rim_height(a)


def revolved_shell(name, loops, steps, c, m, irregular=False):
    angles = [TAU * i / steps for i in range(steps)]
    vertices = []
    for radius, height in loops:
        for a in angles:
            d = radius + edge_variation(a) * (radius / RECORD_R) ** 9 if irregular else radius
            z = top_surface(radius, a) if height is None else height
            if irregular and radius >= 150.4 and height is not None:
                z += rim_height(a) * max(0, (height - 0.7) / 6.0)
            vertices.append((d * math.cos(a), d * math.sin(a), z))
    faces = []
    n = len(loops)
    for i in range(n):
        first, second = i * steps, ((i + 1) % n) * steps
        for j in range(steps):
            k = (j + 1) % steps
            faces.append((first + j, first + k, second + k, second + j))
    return mesh(name, vertices, faces, c, m)


def make_ice(c, m):
    loops = [(HOLE_R + 0.25, 0.07), (70, 0.06), (128, 0.035),
             (148.5, 0.07), (150.4, 0.19), (151.54, 0.49), (152.17, 1.32),
             (152.43, 2.55), (152.51, 3.88), (152.37, 5.06), (152.03, 5.76),
             (151.59, 6.20), (151.2, None)]
    # Geometry defines the groove relief, independent of the material.
    loops += [(151 - i * 0.25, None) for i in range(337)]
    loops += [(66.7, 6.26), (LABEL_R, 6.26), (11, 6.26), (HOLE_R + 0.25, 6.26),
              (HOLE_R + 0.045, 6.15), (HOLE_R, 5.91), (HOLE_R, 0.39)]
    ice = revolved_shell("Ice Baby | grooved solid ice", loops, 480, c, m, irregular=True)
    ice["Nominal diameter (mm)"] = 304.8
    ice["Spindle hole diameter (mm)"] = 2 * HOLE_R
    ice["Notes"] = "Solid refractive ice shell with geometric grooves and a through-hole."
    return ice


def polar(r, a, h):
    return r * math.cos(a), r * math.sin(a), h


def fracture(c, m, name, start, end, angle, width, seed):
    rng = random.Random(seed)
    vertices = []
    steps = int((end - start) * 0.82)
    phase = rng.uniform(0, TAU)
    for i in range(steps + 1):
        t = i / steps
        r = start + (end - start) * t
        a = angle + 0.027 * math.sin(t * 7 + phase) + 0.012 * math.sin(t * 15 + phase * 2)
        a += rng.uniform(-0.006, 0.006)
        h = 4.32 + 0.6 * math.sin(t * 8 - phase) + rng.uniform(-0.29, 0.29)
        w = width * (0.14 + 0.86 * math.sin(math.pi * t) ** 0.48)
        vertices += [polar(r, a - w * 0.50 / r, h - 1.1 * w),
                     polar(r + 0.22, a, h + 0.12),
                     polar(r, a + w / r, min(5.85, h + 0.86 * w))]
    faces = []
    for i in range(steps):
        a = i * 3
        faces.extend(((a, a + 1, a + 4), (a, a + 4, a + 3),
                      (a + 1, a + 2, a + 4), (a + 2, a + 5, a + 4)))
    return mesh(name, vertices, faces, c, m)


def frozen_strata(c, m, rng):
    vertices, faces = [], []
    for i in range(124):
        r = rng.uniform(69, 150.5)
        a0, sweep = rng.uniform(0, TAU), rng.uniform(0.09, 1.22)
        z = rng.uniform(1.05, 5.22)
        height = rng.uniform(0.07, 0.44)
        width = rng.uniform(0.035, 0.36)
        steps = max(5, int(sweep * 27))
        origin = len(vertices)
        phase = rng.uniform(0, TAU)
        for j in range(steps + 1):
            t = j / steps
            a = a0 + t * sweep
            bend = 0.19 * math.sin(12 * a + phase) + 0.10 * math.sin(25 * a)
            taper = 0.1 + 0.9 * math.sin(math.pi * t) ** 0.58
            vertices += [polar(r + bend, a, z - height * taper),
                         polar(r + bend + width * taper, a, z + height * taper)]
            if j:
                k = origin + 2 * (j - 1)
                faces.append((k, k + 2, k + 3, k + 1))
    mesh("Frozen concentric layers | interrupted translucent laminations", vertices, faces, c, m)


def bubbles(c, m, rng):
    vertices, faces = [], []
    resolution = 10

    def emit(r, a, z, rx, ry, rz):
        start = len(vertices)
        x, y, _ = polar(r, a, z)
        dx, dy = math.cos(a), math.sin(a)
        vertices.append((x, y, z - rz))
        for row in range(1, 6):
            latitude = -math.pi / 2 + math.pi * row / 6
            for k in range(resolution):
                t = TAU * k / resolution
                u = rx * math.cos(latitude) * math.cos(t)
                v = ry * math.cos(latitude) * math.sin(t)
                vertices.append((x + dx * u - dy * v, y + dy * u + dx * v, z + rz * math.sin(latitude)))
        top = len(vertices)
        vertices.append((x, y, z + rz))
        for k in range(resolution):
            l = (k + 1) % resolution
            faces.append((start, start + 1 + l, start + 1 + k))
            for j in range(4):
                a0 = start + 1 + j * resolution
                faces.append((a0 + k, a0 + l, a0 + resolution + l, a0 + resolution + k))
            a0 = start + 1 + 4 * resolution
            faces.append((a0 + k, a0 + l, top))

    rim_sites = (72, 86, 105, 122, 140, 149)
    for i in range(835):
        a = rng.uniform(0, TAU)
        r = (rng.choice(rim_sites) + rng.gauss(0, 1.8) if i < 450 else rng.uniform(68.5, 151.1))
        r = max(67.0, min(151.0, r))
        z = rng.uniform(0.75, 5.44)
        b = rng.uniform(0.075, 0.38)
        if i < 42:
            b = rng.uniform(0.42, 0.91)
            z = rng.uniform(1.4, 4.7)
        if 43 <= i < 245:
            b = rng.uniform(0.105, 0.235)
            emit(r, a, z, b * rng.uniform(3.3, 9.0), b, b * 0.85)
        else:
            emit(r, a, z, b * rng.uniform(0.9, 1.3), b, b * rng.uniform(0.52, 1.0))
    mesh("Entrapped air | bubbles and radial needles", vertices, faces, c, m)


def load_font(filename, license_filename):
    root = Path(globals().get("__file__", "")).parent / "fonts"
    font = bpy.data.fonts.get(filename)
    if font is None:
        font = bpy.data.fonts.load(str(root / filename))
        font.name = filename
        font.pack()
    if not bpy.data.texts.get(license_filename):
        license_file = root / license_filename
        if license_file.is_file():
            bpy.data.texts.load(str(license_file), internal=True)
    return font


def text(name, body, size_mm, at, collection, font, ink, *, fit=None, yaw=0.0):
    data = bpy.data.curves.new(name, "FONT")
    data.font = font
    data.body = body
    data.align_x = 'CENTER'
    data.align_y = 'CENTER'
    data.size = size_mm * MM
    data.resolution_u = 16
    data.fill_mode = 'FRONT'
    data.materials.append(ink)
    obj = bpy.data.objects.new(name, data)
    collection.objects.link(obj)
    obj.rotation_euler.z = yaw
    obj.location = metres((*at, TEXT_Z))
    if fit:
        bpy.context.view_layer.update()
        bounds = obj.bound_box
        left, right = min(v[0] for v in bounds), max(v[0] for v in bounds)
        bottom, top = min(v[1] for v in bounds), max(v[1] for v in bounds)
        sx, sy = fit[0] * MM / (right - left), fit[1] * MM / (top - bottom)
        obj.scale = (sx, sy, 1.0)
        cx, cy = (left + right) * sx / 2, (bottom + top) * sy / 2
        obj.location.x -= cx * math.cos(yaw) - cy * math.sin(yaw)
        obj.location.y -= cx * math.sin(yaw) + cy * math.cos(yaw)
    return obj


def label(parent):
    c = group("03 · Paper label and editable typography", parent)
    matte = label_material()
    revolved_shell("Black paper label | punched spindle", [
        (HOLE_R + 0.08, 6.265), (LABEL_R - 0.14, 6.265), (LABEL_R, 6.32),
        (LABEL_R, 6.43), (LABEL_R - 0.14, LABEL_FACE), (HOLE_R + 0.10, LABEL_FACE),
        (HOLE_R + 0.03, 6.44), (HOLE_R + 0.03, 6.31),
    ], 240, c, matte)
    mono = load_font("IBMPlexMono-Light.ttf", "ibmplexmono-OFL.txt")
    script = load_font("PinyonScript-Regular.ttf", "pinyonscript-OFL.txt")
    ivory, bsdf = material("LABEL | white letterpress ink", "F0F0F2", 0.66)
    bsdf.inputs["Specular IOR Level"].default_value = 0.16
    bsdf.inputs["Emission Color"].default_value = linear("E9ECF1")
    bsdf.inputs["Emission Strength"].default_value = 0.035
    text("Title | Ice", "Ice", 18, (-22.1, 28.6), c, script, ivory,
         fit=(24.7, 23), yaw=math.radians(17))
    text("Title | Baby", "Baby", 18, (16.8, 28.5), c, script, ivory,
         fit=(40.9, 23.5), yaw=math.radians(-14))
    for body, size, x, y in [
        ("GOLDEN STREETS", 3.97, 0, 53.7),
        ("RECORDS", 3.97, 0, 49.5),
        ("33⅓ RPM", 4.49, -50.6, -0.10),
        ("SIDE A", 4.49, 51.4, -0.10),
        ("LIMITED EDITION", 3.93, 0, -46.4),
        ("№ 001/100", 4.62, 0, -51.75),
    ]:
        text(f"Typeset | {body}", body, size, (x, y), c, mono, ivory)
    for i, char in enumerate(CREDIT):
        if char == " ":
            continue
        a = math.radians(256) - i * TAU / (len(CREDIT) + 1.4)
        x, y, _ = polar(9.65, a, 0)
        text(f"Spindle credit {i + 1:02d} | {char}", char, 3.22, (x, y), c, mono, ivory,
             yaw=a - math.pi / 2)
    for start, stop, suffix in [(-38.5, -15.6, "left"), (15.6, 38.5, "right")]:
        mesh(f"Label rule | {suffix}",
             [(start, -0.046, TEXT_Z), (stop, -0.046, TEXT_Z),
              (stop, 0.046, TEXT_Z), (start, 0.046, TEXT_Z)],
             [(0, 1, 2, 3)], c, ivory, smooth=False)
    c["Spindle credit"] = CREDIT


def at(obj, target):
    obj.rotation_euler = (Vector(metres(target)) - obj.location).to_track_quat('-Z', 'Y').to_euler()


def area(name, location, target, energy, width, height, rgb, collection):
    data = bpy.data.lights.new(name, 'AREA')
    data.shape = 'RECTANGLE'
    data.size, data.size_y = width * MM, height * MM
    data.energy = energy
    data.color = rgb
    obj = bpy.data.objects.new(name, data)
    collection.objects.link(obj)
    obj.location = metres(location)
    at(obj, target)
    return obj


def render_settings(scene):
    scene.unit_settings.system = 'METRIC'
    scene.unit_settings.length_unit = 'MILLIMETERS'
    scene.render.engine = 'CYCLES'
    scene.cycles.use_denoising = bool(getattr(_cycles, "with_openimagedenoise", False))
    scene.cycles.samples = 128 if scene.cycles.use_denoising else 192
    scene.cycles.adaptive_threshold = 0.015
    scene.cycles.max_bounces = 12
    scene.cycles.transmission_bounces = 9
    scene.cycles.volume_bounces = 2
    scene.cycles.transparent_max_bounces = 12
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGB'
    scene.view_settings.view_transform = 'AgX'
    scene.view_settings.look = 'AgX - Medium High Contrast'
    scene.view_settings.exposure = -2.5


def standalone_stage(scene, top):
    render_settings(scene)
    stage = group("Studio | matching walnut turntable light", scene.collection)
    world = bpy.data.worlds.new(scene.name + " | smoke grey bounce")
    world.use_nodes = True
    world.node_tree.nodes["Background"].inputs["Color"].default_value = (0.29, 0.33, 0.40, 1)
    world.node_tree.nodes["Background"].inputs["Strength"].default_value = 0.15
    scene.world = world
    floor, surface = material("STUDIO | black charcoal sweep", "090A0E", 0.89)
    surface.inputs["Specular IOR Level"].default_value = 0.19
    mesh("Black studio sweep", [(-12000, -12000, -0.095), (12000, -12000, -0.095),
         (12000, 12000, -0.095), (-12000, 12000, -0.095)], [(0, 1, 2, 3)], stage, floor, smooth=False)
    camera_data = bpy.data.cameras.new("Camera | Ice Baby")
    camera = bpy.data.objects.new(camera_data.name, camera_data)
    stage.objects.link(camera)
    camera_data.clip_start, camera_data.clip_end = 0.005, 30
    scene.camera = camera
    if top:
        camera.location = metres((0, 0, 620))
        camera_data.type = 'ORTHO'
        camera_data.ortho_scale = 0.340
        scene.render.resolution_x = scene.render.resolution_y = 2048
        scene.render.filepath = "//ice-baby-overhead.png"
    else:
        camera.location = metres((225, -381, 178))
        camera_data.lens = 46
        at(camera, (0, 0, 1.8))
        scene.render.resolution_x, scene.render.resolution_y = 1900, 1360
        scene.render.filepath = "//ice-baby-edge.png"
    # Same warm key and cool bounce in platter-relative space as in the walnut scene.
    area("Key | warm window from upper left", (-369, 310, 485), (1, 0, -26),
         45, 385, 540, (1.0, 0.86, 0.72), stage)
    area("Fill | cool bounced card", (451, -210, 440), (116, -20, -30),
         8, 470, 470, (0.77, 0.85, 1.0), stage)
    area("Edge | long softbox", (345, 430, 230), (89, 30, -11),
         11, 290, 490, (1.0, 0.89, 0.74), stage)
    area("Overhead bounce | brushed metal", (-22, -46, 305), (5, -27, -19),
         6, 330, 375, (1.0, 0.94, 0.86), stage)
    area("Ice rim card | cool grazing stripe", (138, -188, 88 if top else 60), (9, 0, 6),
         5.0 if top else 7.8, 278, 49, (0.59, 0.76, 1.0), stage)
    return scene


def install_on_turntable(scene, record):
    scene.name = "03 | Ice Baby · On the turntable"
    mount = bpy.data.objects.new("Ice Baby | aligned to original turntable spindle", None)
    mount.instance_type = 'COLLECTION'
    mount.instance_collection = record
    mount.location = metres((-51, 0, 59.69))
    scene.collection.objects.link(mount)
    for name in ("Center puck | brushed face", "Center puck | felt gasket"):
        part = scene.objects.get(name)
        if part:
            part.hide_render = True
            for layer in scene.view_layers:
                part.hide_set(True, view_layer=layer)
    scene.cycles.transmission_bounces = 9
    scene.cycles.max_bounces = 12
    scene.cycles.volume_bounces = 2
    scene.cycles.transparent_max_bounces = 12
    scene.render.filepath = "//ice-baby-on-turntable.png"


def build():
    original = bpy.context.scene
    turntable = bpy.data.scenes.get("01 | Top")
    inspection = bpy.data.scenes.get("02 | Three-quarter")
    top = bpy.data.scenes.new("01 | Ice Baby · Top")
    edge = bpy.data.scenes.new("02 | Ice Baby · Edge")
    if bpy.context.window:
        bpy.context.window.scene = top
    record = group("ICE BABY | editable 12-inch record", top.collection)
    edge.collection.children.link(record)
    solid = group("01 · Grooved solid ice", record)
    inside = group("02 · Bubbles, laminations and fissures", record)
    make_ice(solid, ice_material())
    air = inclusion_material("ICE | air inclusions", "E4F1FB", 0.55, 0.16)
    crack = inclusion_material("ICE | fractured planes", "DFECFA", 0.15, 0.23)
    layers = inclusion_material("ICE | translucent freezing laminations", "C8DFF8", 0.49, 0.23)
    rng = random.Random(3217)
    bubbles(inside, air, rng)
    frozen_strata(inside, layers, rng)
    for name, r0, r1, angle, width in [
        ("01 | west-south split", 66.9, 151.1, 229, 1.92),
        ("01a | fork", 100, 136, 222, 0.5),
        ("02 | north-east split", 70, 151, 42, 2.10),
        ("02a | fork", 117, 149, 48, 0.62),
        ("03 | right-edge stress line", 101, 151, 351, 0.57),
        ("04 | small upper vein", 94, 131, 102, 0.34),
        ("05 | south rim vein", 112, 150, 292, 0.38),
        ("06 | lateral frost seam", 96, 141, 165, 0.32),
    ]:
        fracture(inside, crack, "Ice fissure " + name, r0, r1, math.radians(angle), width, rng.randrange(100000))
    label(record)
    standalone_stage(top, True)
    standalone_stage(edge, False)
    if turntable:
        install_on_turntable(turntable, record)
        if inspection:
            bpy.data.scenes.remove(inspection)
    elif original.name == "Scene" and set(original.objects.keys()) <= {"Camera", "Cube", "Light"}:
        bpy.data.scenes.remove(original)
    for screen in bpy.data.screens:
        for ar in screen.areas:
            if ar.type == 'VIEW_3D':
                ar.spaces.active.region_3d.view_perspective = 'CAMERA'
                ar.spaces.active.overlay.show_overlays = False
                ar.spaces.active.shading.color_type = 'MATERIAL'
    path = Path(globals().get("__file__", ""))
    if path.is_file() and not bpy.data.texts.get(path.name):
        bpy.data.texts.load(str(path), internal=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else [])
    build()
    if args.output:
        path = args.output.expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        bpy.ops.wm.save_as_mainfile(filepath=str(path), compress=True, relative_remap=False)


if __name__ == "__main__":
    main()
